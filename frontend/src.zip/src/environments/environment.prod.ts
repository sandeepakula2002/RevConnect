export const environment = {
  production: true,
  apiUrl: "http://13.55.136.121:8080/api"
};
